#include<iostream>
#include<fstream>
#include<string>
using namespace std;
class mdetail{
    public:
    string name;
    int id, date, month, year;
    int price;
};
class cdata{
    public:
    string rname, rpass, luname, lupass;
    string bname;
    long long bcontactno;
};
void movietiming();
void addmovie();
void adminlogin();
void mainmenu();
void contactus();
void viewmovies();
void deletemovie();
void regcustomer();
void login();
void showbooking();
void cmainmenu();
void bookmovie();
int main(){

    cout<<"\t\t\t======================================"<<endl;
    cout<<"\t\t\t======================================"<<endl;
    cout<<"\t\t\tMOVIE TICKET MANAGEMENT SYSTEM"<<endl;
    m:
    cout<<"\t\t\tPress 1 for Admin login."<<endl;
    cout<<"\t\t\tPress 2 for Customer login."<<endl;
    int choice;
    cin>>choice;
    switch(choice){
        case 1:
        adminlogin();
        break;
        case 2:
        cmainmenu();
        default:
        cout<<"\t\t\tChoose valid option"<<endl;
        goto m;
    }



return 0;
}
void adminlogin(){
    m:
    string username, password;
    cout<<"\t\t\tEnter username  :"<<endl;
    cin>>username;
    cout<<"\t\t\tEnter password :"<<endl;
    cin>>password;
    if(username=="admin" || password=="sendrela" || password=="kundan" || password=="ravi"){
        mainmenu();
        }else{
            cout<<"\t\t\tYou have entered wrong username or password, please Login again."<<endl;
            goto m;
        }
}
void mainmenu(){
    int choice;
        m:
        cout<<"\t\t\tPress 1 to Add movie."<<endl;
        cout<<"\t\t\tPress 2 to view all movies details."<<endl;
        cout<<"\t\t\tPress 3 to delete a Movie."<<endl;
        cout<<"\t\t\tPress 4 to view all bookings."<<endl;
        cin>>choice;
                switch(choice){
                case 1:
                addmovie();
                break;
                case 2:
                viewmovies();
                break;
                case 3:
                deletemovie();
                break;
                case 4:
                showbooking();
                break;
                default:
                cout<<"\t\t\tChoose valid option"<<endl;
                goto m;
            }
}
void cmainmenu(){
    int choice;
        m:
        cout<<"\t\t\tPress 1 to login."<<endl;
        cout<<"\t\t\tPress 2 to Register."<<endl;
        cin>>choice;
                switch(choice){
                case 1:
                login();
                break;
                case 2: 
                regcustomer();
                break;
                default:
                cout<<"\t\t\tChoose valid option"<<endl;
                goto m;
            }
}
void addmovie(){
    int choice;
    mdetail m1;
    cout<<"\t\t\tEnter movie ID :"<<endl;
    cin>>m1.id;
    cout<<"\t\t\tEnter movie Name :"<<endl;
    cin>>m1.name;
    cout<<"\t\t\tEnter price of the ticket :"<<endl;
    cin>>m1.price;
    cout<<"\t\t\tEnter Releasing date :"<<endl;
    cin>>m1.date>>m1.month>>m1.year;
    ofstream f1;
    f1.open("mdata.txt", ios::app);
    f1<<m1.id<<' '<<m1.name<<' '<<' '<<m1.price<<' '<<m1.date<<"-"<<m1.month<<"-"<<m1.year<<endl;
    f1.close();
    cout<<"\t\t\tMovie added sucessfully."<<endl;
    m:
    cout<<"\t\t\tPress 1 to add more movies."<<endl;
    cout<<"\t\t\tPress 2 for main menu."<<endl;
    cin>>choice;
    switch(choice){
        case 1:
        addmovie();
        break;
        case 2:
        mainmenu();
        default:
        cout<<"\t\t\tChoose a valid option"<<endl;
        goto m;
    }
}
void viewmovies(){
    ifstream f2;
    f2.open("mdata.txt");
    if(f2.is_open()){
        cout<<f2.rdbuf();
    }
    f2.close();
    mainmenu();
}
void deletemovie(){
    int id;
    mdetail m1;
    cout<<"\t\t\tEnter movie id you want to Delete :"<<endl;
    cin>>id;
    ifstream r1;
    r1.open("mdata.txt");
    ofstream f1;
    f1.open("temp.txt");
    r1>>m1.id>>m1.name>>m1.price>>m1.date>>m1.month>>m1.year;
    while(!r1.eof()){
        if(m1.id!=id){
            f1<<m1.id<<' '<<m1.name<<' '<<m1.price<<' '<<m1.date<<"-"<<m1.month<<"-"<<m1.year<<endl;
        }
        r1>>m1.id>>m1.name>>m1.price>>m1.date>>m1.month>>m1.year;
        }
    
    r1.close();
    f1.close();
    remove("mdata.txt");
    rename("temp.txt", "mdata.txt");
    cout<<"Movie deleted"<<endl;
    mainmenu();
}
void regcustomer(){
    cdata c1;
    cout<<"\t\t\tWELCOME TO REGISTRATION"<<endl;
    cout<<"\t\t\tEnter username :"<<endl;
    cin>>c1.rname;
    cout<<"\t\t\tEnter password :"<<endl;
    cin>>c1.rpass;
    ofstream f1;
    f1.open("cdata.txt", ios::app);
    f1<<c1.rname<<' '<<c1.rpass<<endl;
    f1.close();
    cout<<"\t\t\tHello "<<c1.rname<<" you are registred sucessfully. please login"<<endl;
    login();
    
}
void login(){
    cdata c1;
    string lname, lpass;
    int count=0;
    int choice;
    cout<<"\t\t\tWELCOME TO LOGIN "<<endl;
    cout<<"\t\t\tEnter username :"<<endl;
    cin>>lname;
    cout<<"\t\t\tEnter password :"<<endl;
    cin>>lpass;
    ifstream r2;
    r2.open("cdata.txt");
    while(!r2.eof()){
        r2>>c1.luname>>c1.lupass;
    }
    if(lname==c1.luname && lpass==c1.lupass){
        count=1;
    }
    if(count==1){
        cout<<"You are sucessfully logined"<<endl;
        cout<<"\t\t\tPress 1 to view movies details."<<endl;
        cout<<"\t\t\tPress 2 to Book Movie."<<endl;
        cout<<"\t\t\tPress 3 to contact Us."<<endl;
        cout<<"\t\t\tPress 4 to EXIT."<<endl;
        cin>>choice;
        switch(choice){
            case 1:
            viewmovies();
            break;
            case 2:
            movietiming();
            break;
            case 3:
            contactus();
            break;
            case 4:
            main();
            default:
            cout<<"\t\t\tPlease enter valid option" <<endl;
        }
    }
}
void bookmovie(){
    viewmovies();
    string name;
    long long cnum;
    int id, no_of_ticket;
    mdetail m1;
    cout<<"\t\t\tEnter movie id you want to book :"<<endl;
    cin>>id;
    cout<<"\t\t\tEnter your name :"<<endl;
    cin>>name;
    cout<<"\t\t\tEnter your contact number :"<<endl;
    cin>>cnum;
    cout<<"\t\t\tEnter number of ticket you want to book :"<<endl;
    cin>>no_of_ticket;
    ifstream r1;
    r1.open("mdata.txt");
    ofstream f1;
    f1.open("booking.txt", ios::app);
    r1>>m1.id>>m1.name>>m1.price>>m1.date>>m1.month>>m1.year;
    int total=m1.price*no_of_ticket;
    while(!r1.eof()){
        if(m1.id==id){
            f1<<name<<' '<<cnum<<' '<<no_of_ticket<<' '<<total<<endl;
            f1<<m1.id<<' '<<m1.name<<' '<<m1.price<<' '<<m1.date<<"-"<<m1.month<<"-"<<m1.year<<endl;
            f1<<"++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"<<endl;
            cout<<"Your name :"<<name<<endl;
            cout<<"Contact no :"<<cnum<<endl;
            cout<<"Total price :"<<total<<endl;
            cout<<m1.id<<' '<<m1.name<<' '<<m1.price<<' '<<m1.date<<"-"<<m1.month<<"-"<<m1.year<<endl;
        }
        r1>>m1.id>>m1.name>>m1.price>>m1.date>>m1.month>>m1.year;
        }
    
    r1.close();
    f1.close();
    cout<<"Movie booked sucessfully"<<endl;
    cmainmenu();
}
void showbooking(){
    ifstream f1;
    f1.open("booking.txt");
    while(!f1.eof()){
        cout<<f1.rdbuf();
    }
    mainmenu();
}
void contactus(){
    cout<<"\t\t\tSENDRELA GULZAR sendrelagulzar@gmail.com"<<endl;
    cout<<"\t\t\tRAVI KUMAR ravikumar9006997@gmail.com"<<endl;
    cout<<"\t\t\tKUNDAN stevejohn404@gmail.com for jhaadu pocha"<<endl;
    mainmenu();
}
void movietiming(){
    int choice;
    cout<<"\t\t\tMOVIE TIMING "<<endl;
    cout<<"\t\t\tPRESS 1 FOR 09:00 AM"<<endl;
    cout<<"\t\t\tPRESS 2 FOR 12:00 AM"<<endl;
    cout<<"\t\t\tPRESS 3 FOR 15:00 AM"<<endl;
    cout<<"\t\t\tPRESS 4 FOR 17:00 AM"<<endl;
    cout<<"\t\t\tPRESS 5 FOR 18:00 AM"<<endl;
    cin>>choice;
    switch(choice){
        case 1:
        bookmovie();
        break;
        case 2:
        bookmovie();
        break;
        case 3:
        bookmovie();
        break;
        case 4:
        bookmovie();
        break;
        case 5:
        bookmovie();
        break;
        default:
        cout<<"Choose valid option"<<endl;
    }
}